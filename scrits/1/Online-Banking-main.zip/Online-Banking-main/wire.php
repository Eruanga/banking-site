<?php include 'includes/timeoutable.php' ?>

<body background: src="img/picc3.jpg">
    <?php include 'includes/db.php'; ?>
<?php include 'header2.php';  ?>
<div style="height:100px;"></div>
<div class="container">
    <div class="row">
        <div class="paymentCont">
                        <div class="headingWrap">
                                <h3 class="headingTop text-center">You have selected the Debit Card option of funding</h3>  
                                <p class="text-center"><strong>NB:</strong> Please fill in the field bellow</p>
                        </div>
                        <div class="container text-center">
    <div class="row">
        <!-- You can make it whatever width you want. I'm making it full width
             on <= small devices and 4/12 page width on >= medium devices -->
        <div class="col-xs-12">
        
        
            Dear Client,
Thank you for your interest in trading with 24option.
You are just a final step away from beginning to trade with the world’s leading Forex and CFD platform -
completing your wire transfer.
Following is 24option’s financial institution information for wire transfers.

Please note:
• You can only transfer funds to your 24option account from an account held in the same name.
• Third-party transfers will not be accepted.
• The company does not accept cash deposits.
• Wire transfers require a minimum deposit of $500 or its equivalent in your account currency.
• Wire transfer is available in EUR, GBP & CHF


EUR Wire transfer
Beneficiary: RICHFIELD CAPITAL LIMITED
Bank: Wirecard Bank AG
Bank Address: Einsteinring 35, 85609, Aschheim, Germany
Swift: WIREDEMMXXX
                        <div class="footerNavWrap clearfix">
                            <div class="btn btn-success pull-left btn-fyi"><span class="glyphicon glyphicon-chevron-left"></span> RETURN</div>
                            
                        </div>
                    </div>
        
    </div>
</div>
</div>
</div>
</div>
            <?php include 'footer.php' ?>
</body>
