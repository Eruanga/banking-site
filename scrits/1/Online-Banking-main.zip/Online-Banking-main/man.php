<?php include 'includes/timeoutable.php' ?>

<body>
    <?php include 'includes/db.php'; ?>
        <!--Include here-->
        <?php include 'header.php'; ?>
<div style="height:85px;"></div>
  <!-- Start WOWSlider.com BODY section -->
<div id="wowslider-container1">
<div class="ws_images"><ul>
    <li><a href="register.php" target="_blank"><img src="data1/images/1.jpg" alt="Trade with confidence on the world's leading social trading platform" title="welcome to 34 options, Trade with confidence on the world's leading social trading platform" id="wows1_0"/></a>Get Started</li>
    <li><a href="www.34option.net"><img src="https://i.ibb.co/qR9JWJg/Benefit-from-a-packed-product-suite-of-Forex-CFDs-Binary-34-Options-provides-an-enjoyable-trading-experience-with-astraightforward-and-intuitive-platform.png" alt="Benefit from a packed product suite of ForexCFDs & Binary.34Options provides an enjoyable trading experience with astraightforward and intuitive platform" title="Benefit from a packed product suite of ForexCFDs & Binary.34Options provides an enjoyable trading experience with astraightforward and intuitive platform" id="wows1_1"/></a></li>
    <li><img src="https://i.ibb.co/RbVYxR3/t.jpg" alt="New to trading?" title="New to trading?" id="wows1_2"/>Enjoy the services of our professioner traders.</li>
  </ul></div>
  <div class="ws_bullets"><div>
    <a href="#" title="welcome to 34 Option, one of a kind binary option trade, making sure you earn as espected"><span><img src="data1/tooltips/1.jpg" alt="welcome to 34 Option, one of a kind binary option trade, making sure you earn as espected"/>1</span></a>
    <a href="#" title="Benefit from a packed product suite of ForexCFDs & Binary.34Options provides an enjoyable trading experience with astraightforward and intuitive platform"><span><img src="data1/tooltips/benefitfromapackedproductsuiteofforexcfdsbinary.34optionsprovidesanenjoyabletradingexperiencewithastraightforwardandintuitiveplatform.png" alt="Benefit from a packed product suite of ForexCFDs & Binary.34Options provides an enjoyable trading experience with astraightforward and intuitive platform"/>2</span></a>
    <a href="#" title="Unlimited Options"><span><img src="data1/tooltips/capturer.jpg" alt="Unlimited Options"/>3</span></a>
  </div></div><div class="ws_script" style="position:absolute;left:-99%"><a href="http://wowslider.net">slideshow javascript</a> by WOWSlider.com v8.8</div>
<div class="ws_shadow"></div>
</div>  
<script type="text/javascript" src="engine1/wowslider.js"></script>
<script type="text/javascript" src="engine1/script.js"></script>
<!-- End WOWSlider.com BODY section -->
      
<div style="background: gold;color: black;left: 0;position: fixed;right: 0;top: 0;z-index: 1030;" ><div class="container"> <marquee behavior="scroll" direction="left" scrollamount="3">Our servers are distributed around the world. The intelligent <b style='text-transform: uppercase;'>load balancing and fail-over system</b> ensures you are up and running 99.9% of the time. Get <b style='text-transform: uppercase;'>10%</b> bonus on deposit above <b>$999</b>.</marquee></div></div><br>
  <section id="feature" style="background-color: black;">
    <div class="container">
      <div class="center wow fadeInDown">
        <h3 style="color: white;"><strong>Welcome to 34 options</strong></h3>
        <p class="" style="color: white;">Your Innovative and award winning stock Broker, you can explore a world of financial opportunities from a single screen: Forex, CFDs & Binary

Join us and trade on a broad variety of assets and instruments including: stocks, commodities, currencies & indices, for a completely tailored trading experience!</p>
      </div>

      <div class="row">
        <div class="features">
          <div class="col-md-4 col-sm-6 wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="600ms">
            <div class="feature-wrap">
              <i class="fa fa-laptop"></i>
              <h2 style="color: white;">A Regulated Broker since 2019</h2>
              <h3>34Option is fully regulated by the CySec.</h3>
            </div>
          </div>
          <!--/.col-md-4-->

          <div class="col-md-4 col-sm-6 wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="600ms">
            <div class="feature-wrap">
              <i class="fa fa-comments"></i>
              <h2 style="color: white;">Professional Support</h2>
              <h3>Round the clock expert support</h3>
            </div>
          </div>
          <!--/.col-md-4-->

          <div class="col-md-4 col-sm-6 wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="600ms">
            <div class="feature-wrap">
              <i class="fa fa-lock"></i>
              <h2 style="color: white;">Secured by SSL</h2>
              <h3>Our platform is secured by Comodo security and a 64-bit encryption technology</h3>
            </div>
          </div>
          <!--/.col-md-4-->

          <div class="col-md-4 col-sm-6 wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="600ms">
            <div class="feature-wrap">
              <i class="fa fa-shield"></i>
              <h2 style="color: white;">(2fa) Authentication</h2>
              <h3>Your account can be secured 
            with two-factor-authentication (2FA).</h3>
            </div>
          </div>
          <!--/.col-md-4-->

          <div class="col-md-4 col-sm-6 wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="600ms">
            <div class="feature-wrap">
              <i class="fa fa-cogs"></i>
              <h2 style="color: white;">Account Security</h2>
              <h3>The entire infrastructure runs on highly secured servers. 
              </h3>
            </div>
          </div>
          <!--/.col-md-4-->

          <div class="col-md-4 col-sm-6 wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="600ms">
            <div class="feature-wrap">
              <i class="fa fa-user"></i>
              <h2 style="color: white;">Trader's Support</h2>
              <h3>Request the help of approved professionals to trade on your behalf.</h3>
            </div>
          </div>
          <!--/.col-md-4-->
        </div>
        <!--/.services-->
      </div>
      <!--/.row-->
    </div>
    <!--/.container-->
  </section>
  <!--/#feature-->

  
         <!--Main Navigation-->
        
            
                <div class="full-bg-img" style="background-image: url(https://i.ibb.co/1mCSH4q/technologies-abstract-background-with-plexus-connections-wire-frame-web-seamless-looping-r8eid3614g-thumbnail-full01.png); background-repeat: no-repeat; background-size: cover;">
                    <div class="container flex-center">
                        <div class="row flex-center pt-5 mt-3">
                            <div class="col-md-6 text-center text-md-left margins">
                                <div class="white-text">
                                    <h2 class="h2-responsive wow fadeInLeft" data-wow-delay="0.3s" style="color: white;">Trade with our mobile app </h2>
                                        <hr class="hr-light wow fadeInLeft" data-wow-delay="0.3s">
                                        <h6 class="wow fadeInLeft" data-wow-delay="0.3s" style="color: white">Trade Forex/Binary all on our advanced, web-based trading platform designed with you, the user in mind. With our platform, you can trade on the largest lists of assets in the industry. From Currency pairs, and Commodities to stocks and indices, we have it all. </h6>
                                        <br>
                                        <a class="btn btn-outline-white wow fadeInLeft" data-wow-delay="0.3s">Learn more</a>
                                        <a class="btn btn-outline-white wow fadeInLeft" data-wow-delay="0.3s">Download
                                            <i class="fa fa-android left right" aria-hidden="true"></i>
                                            <i class="fa fa-apple left" aria-hidden="true"></i>
                                            <i class="fa fa-windows" aria-hidden="true"></i>
                                        </a>
                                </div>
                            </div>

                            <div class="col-md-6 wow fadeInRight d-flex justify-content-center" data-wow-delay="0.4s">
                                <img src="images/11.png" alt="" class="img-responsive">
                            </div>
                        </div>
                        <h2 class="text-center" style="color: white;">START TRADING  IN JUST 3 EASY STEPS</h2>
                    </div>
                </div>
            

        
        <!--Main Navigation-->

               

        <!--Main Layout-->
        <main>

            <div class="container">

                <!--Grid row-->
                <div class="row py-5">

                    <!--Grid column-->
                    <div class="col-md-12 text-center">

                        <!--<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>-->

                    </div>
                    <!--Grid column-->

                </div>
                <!--Grid row-->

            </div>

        </main>
        <!--Main Layout-->
 </section>
  <!--/#recent-works-
<body class="homepage">
  <section id="services" class="service-item">
    <div class="container">
      <div class="center wow fadeInDown">
        <h2>Our Service</h2>
        <p class="lead">The MT4 platform is one of the most popular charting and analysis softwares used by traders of all levels.  The MT4 comes with all of the most popular charting tools and offers immediate order execution and real-time results.</p>
      </div>

      <div class="row">

        <div class="col-sm-6 col-md-4">
          <div class="media services-wrap wow fadeInDown">
            <div class="pull-left">
              <img class="img-responsive" src="images/services/services1.png">
            </div>
            <div class="media-body">
              <h3 class="media-heading">SEO Marketing</h3>
              <p>Lorem ipsum dolor sit ame consectetur adipisicing elit</p>
            </div>
          </div>
        </div>

        <div class="col-sm-6 col-md-4">
          <div class="media services-wrap wow fadeInDown">
            <div class="pull-left">
              <img class="img-responsive" src="images/services/services2.png">
            </div>
            <div class="media-body">
              <h3 class="media-heading">SEO Marketing</h3>
              <p>Lorem ipsum dolor sit ame consectetur adipisicing elit</p>
            </div>
          </div>
        </div>

        <div class="col-sm-6 col-md-4">
          <div class="media services-wrap wow fadeInDown">
            <div class="pull-left">
              <img class="img-responsive" src="images/services/services3.png">
            </div>
            <div class="media-body">
              <h3 class="media-heading">SEO Marketing</h3>
              <p>Lorem ipsum dolor sit ame consectetur adipisicing elit</p>
            </div>
          </div>
        </div>

        <div class="col-sm-6 col-md-4">
          <div class="media services-wrap wow fadeInDown">
            <div class="pull-left">
              <img class="img-responsive" src="images/services/services4.png">
            </div>
            <div class="media-body">
              <h3 class="media-heading">STRATEGY & FINANCE MANAGEMENT</h3>
              <p>As a Brokerage Firm fully focused on Forex and Global indices, we are deeply committed to providing our clients with the best Investment solutions.</p>
            </div>
          </div>
        </div>

        <div class="col-sm-6 col-md-4">
          <div class="media services-wrap wow fadeInDown">
            <div class="pull-left">
              <img class="img-responsive" src="images/services/services5.png">
            </div>
            <div class="media-body">
              <h3 class="media-heading">Mobile Friendly Interface</h3>
              <p>The system is designed with simplicity and work across all platforms, ranging from all mobile devices, Tablet to PC</p>
            </div>
          </div>
        </div>

        <div class="col-sm-6 col-md-4">
          <div class="media services-wrap wow fadeInDown">
            <div class="pull-left">
              <img class="img-responsive" src="images/services/services6.png">
            </div>
            <div class="media-body">
              <h3 class="media-heading">SEO Marketing</h3>
              <p>Lorem ipsum dolor sit ame consectetur adipisicing elit</p>
            </div>
          </div>
        </div>
      </div>
      <!--/.row-->
    </div>
    <!--/.container-->
  </section>
  <!--/#services-->


  <section id="feature" class="transparent-bg">
    <div class="container">
      <div class="get-started center wow fadeInDown"  style="background-image: url(https://i.ibb.co/1mCSH4q/technologies-abstract-background-with-plexus-connections-wire-frame-web-seamless-looping-r8eid3614g-thumbnail-full01.png); background-repeat: no-repeat; background-size: cover;">
        <h2 style="color: white;">Ready to get started</h2>
        <p class="lead" style="color: white;">34 options is fully equipped and optimized to bring you the latest in trading technology and ensure your trading experience is smooth and hassle-free.</p>
        <div class="request">
          <h4><a href="register.php" style="background-color: gold;">Create an Account</a></h4>
        </div>
      </div>
      <!--/.get-started-->

      
    <!--/.container-->
  </section>
  <!--/#feature-->



  
<section id="middle">
    <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="row">
              <div class="col-sm-6 col-lg-6">
                <div class="wow fadeInRight" data-wow-offset="0" data-wow-delay="0.5s">
      <img src="https://i.ibb.co/WszMS9T/smartmockups-jq8oitso.png" class="img-responsive">
    </div>
              </div>
              <div class="col-sm-6 col-lg-6">
                <h4>BEST IN THE INDUSTRY</h4>
                <h2>MORE REASONS TO CHOOSE 34OPTION?</h2>
                <p>Benefit from a packed product suite of Forex/CFDs & Binary. 34Option provides an enjoyable trading experience with a straightforward and intuitive platform.</p>
                <div class="progress">
                  <div class="progress-bar progress-bar-warning progress-bar-striped active" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 89%">
                    TRADERS FRIENDLY 89%
                  </div>
                </div>
                <div class="progress">
                  <div class="progress-bar progress-bar-warning progress-bar-striped active" role="progressbar" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100" style="width: 82%">
                    INSTANT DEPOSIT 82%
                  </div>
                </div>
                <div class="progress">
                  <div class="progress-bar progress-bar-warning progress-bar-striped active" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 100%">
                    INSTANT WITHDRAWAL TO WALLET 100%
                  </div>
                </div>
                <div class="progress">
                  <div class="progress-bar progress-bar-warning progress-bar-striped active" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 99%">
                    24/7 SUPPORT 99%
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    <!--/.container-->
  </section>
  <!--/#middle-->
  <div class="text-center" style="margin-top:0px;"><img src="images/juve.jpg" width="100%;" height="30%;"> </div>
 <div class="container">
<center> <h2 class="text-uppercase">Market Today</h2></center>
                   <!-- TradingView Widget BEGIN -->
<span id="tradingview-copyright"><a ref="nofollow noopener" target="_blank" href="http://www.tradingview.com" style="color: rgb(173, 174, 176); font-family: "Trebuchet MS", Tahoma, Arial, sans-serif; font-size: 13px;">Forex Quotes by <span style="color: #3BB3E4">TradingView</span></a></span>
<script src="https://s3.tradingview.com/external-embedding/embed-widget-forex-cross-rates.js">{
  "currencies": [
    "EUR",
    "USD",
    "JPY",
    "GBP",
    "CHF",
    "AUD",
    "CAD",
    "NZD",
    "CNY",
    "TRY",
    "SEK",
    "NOK",
    "DKK",
    "ZAR",
    "HKD",
    "SGD",
    "THB",
    "MXN",
    "IDR",
    "KRW",
    "PLN",
    "ISK",
    "KWD",
    "PHP"
  ],
  "width": "100%",
  "height": "100%",
  "locale": "en"
}</script>
<!-- TradingView Widget END -->

                </div>
            <!-- End off Brand section -->
            
  <section id="bottom" style="background-color: black;">
    <div class="container wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="600ms">
      <div class="row">
        <div class="col-md-3 col-sm-6">
          <div class="widget">
            <div class="text-center" style="margin-top:0px;"><img src="images/mtd.png" width="100%;" height="25%;"> </div>
          </div>
        </div>
        <!--/.col-md-3-->

        <div class="col-md-3 col-sm-6">
          <div class="widget">
            <div class="text-center" style="margin-top:0px;"><img src="images/btc.png" width="50%;" height="25%;"> </div>
          </div>
        </div>
        <!--/.col-md-3-->

        <div class="col-md-3 col-sm-6">
          <div class="widget">
            <h3 style="color: gold">Contact Us</h3>
            <ul>
             <p style="color: gold">
                    <i class="fa fa-home iconFooter mr-3"></i> 228 Vimos street, 2nd floor, Flat/Office 301, 2516 Remka, Nicosia, Cyprus</p>
                <p style="color: gold">
                    <i class="fa fa-envelope iconFooter mr-3"></i>support@34option.net</p>
                <p style="color: gold">
                    <i class="fa fa-phone iconFooter mr-3"></i>  +447456397506</p>
            </ul>
          </div>
        </div>
        <!--/.col-md-3-->

        <div class="col-md-3 col-sm-6">
          <div class="widget">
            <h3 style="color: gold">Quick Links</h3>
            <ul>
              <li><a href="faq.php" style="color: gold">FAQ</a></li>
              <li><a href="index.php" style="color: gold">HOME</a></li>
              <li><a href="https://embed.tawk.to/6187bdb86bb0760a49417e9f/1fjt3q6gl" style="color: gold">Live-Chat</a></li>
            </ul>
          </div>
          </div>
        </div>
        <!--/.col-md-3-->
      </div>
    </div>
  </section>
  <!--/#bottom-->

  <div class="top-bar">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="social">
            <ul class="social-share">
              <li><a href="#"><i class="fa fa-facebook"></i></a></li>
              <li><a href="#"><i class="fa fa-twitter"></i></a></li>
              <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
              <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
              <li><a href="#"><i class="fa fa-skype"></i></a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <!--/.container-->
  </div>
  <!--/.top-bar-->

  <footer id="footer" class="midnight-blue">
    <div class="container">
      <div class="row">
        <div class="col-sm-6">
          &copy; 34Option. All Rights Reserved.
          
        </div>
        <div class="col-sm-6">
          <ul class="pull-right">
            <li><a href="index.php">Home</a></li>
            <li><a href="faq.php">FAQ</a></li>
          </ul>
        </div>
      </div>
    </div>
    <div class="text-center" style="color: white;">Risk warning:  Future forecasts do not constitute a reliable indicator of future performance. Before deciding to trade, you should carefully consider your investment objectives, level of experience and risk tolerance. You should not deposit more than you are prepared to lose. Please ensure you fully understand the risk associated with the product envisaged and seek independent advice, if necessary. Please read our Risk Disclosure document.</div>
  </footer>
  <!--/#footer-->

  <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
  <script src="js/jquery.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.prettyPhoto.js"></script>
  <script src="js/jquery.isotope.min.js"></script>
  <script src="js/wow.min.js"></script>
  <script src="js/main.js"></script>

</body>

</html>
