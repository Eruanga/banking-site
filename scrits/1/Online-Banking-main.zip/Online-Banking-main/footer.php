

  <!--/.top-bar-->
  
   <footer id="footer" class="midnight-blue"  style="background-color: white;">
    <div class="text-center" style="color: black; font-size: 13px; margin-top: 20px;">
        <p>Legal notice | Security | Rates</p>
        <p>&copy; 20<?php echo date('y'); ?>© CaixaBank, S.A. 2022. All rights reserved.</p>.</div>
  </footer>

  <!--/#footer-->

  <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
  <script src="js/jquery.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.prettyPhoto.js"></script>
  <script src="js/jquery.isotope.min.js"></script>
  <script src="js/wow.min.js"></script>
  <script src="js/main.js"></script>
  <script src="main.js"></script>

</body>

</html>
