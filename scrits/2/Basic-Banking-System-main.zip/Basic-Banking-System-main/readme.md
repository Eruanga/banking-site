Task 1: Web Development internship at The Sparks Foundation, this repository contains the source code for a dynamic website used as a basic banking system. Built by using HTML, CSS, Javascript, PHP and MySQL, it allows the user to perform monetary transactions and keep a track of their banking activities.

To use this code, create 5 files: index.html,customer.html, style.css, customer.css and script.js. Paste the corresponding code into each file. Make sure to keep the file names and directory structure consistent.

This code sets up a basic banking system webpage with customers section that shows the balance. You can click the "send" button to send money and can see all the transactions. The balance is updated dynamically on the webpage.

