# Basic-Banking-System
 this repository contains the source code for a dynamic website used as a basic banking system. Built by using HTML, CSS, Javascript, PHP and MySQL, it allows the user to perform monetary transactions and keep a track of their banking activities.  To use this code, create 5 files: index.html,customer.html, style.css, customer.css, script.js.
